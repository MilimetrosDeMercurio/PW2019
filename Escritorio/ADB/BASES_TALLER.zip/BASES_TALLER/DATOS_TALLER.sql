﻿--*** LLAVES PRIMARIAS Y FORANEAS ***--

	
--*** INSERTS ***--

--***********************************************************************************************************--
--Tabla: Alumno--
--Kinder 4--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16981120,'Chancellor','Mendez',4);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16420327,'Ulric','Rollins',4);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16500116,'Tanek','Duncan',4);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16801118,'Samantha','Fischer',4);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16490216,'Camilla','Sharpe',4);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16360718,'Sawyer','Caldwell',4);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16130113,'Marvin','Weaver',4);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16340112,'Ramona','Beard',4);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16971101,'Charles','Frank',4);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16360622,'Faith','Dennis',4);

--kinder 5--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16010603,'Jakeem','Robbins',5);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16840725,'Madison','Kemp',5);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16340111,'Anne','Merritt',5);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16250714,'Melissa','Rutledge',5);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16990801,'Reed','Norris',5);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16820907,'Kennedy','White',5);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16650523,'Chantale','Morrow',5);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16420515,'Cade','Maxwell',5);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16440801,'Riley','Rich',5);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16081015,'Isabella','Haney',5);

--Prepa --
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16381121,'Nina','Burns',6);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16220615,'David','Cooper',6);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16570110,'Carter','Solomon',6);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16980202,'Calvin','Raymond',6);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16800622,'Jessamine','Forbes',6);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16620716,'Xanthus','Chandler',6);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16920319,'Florence','Collins',6);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16260113,'Leila','Suarez',6);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16371118,'Ursula','Harding',6);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16311217,'Ferdinand','Bush',6);

--primero--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16540104,'Baker','Lynch',7);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16560817,'Cecilia','Castaneda',7);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16611027,'Kirby','Langley',7);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16820129,'Jarrod','Finch',7);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16380305,'Dalton','Phelps',7);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16171119,'Reuben','Harrington',8);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16340712,'Leo','Church',7);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16310212,'Moana','Cole',7);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16471222,'Paul','Lindsay',7);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16421010,'Nero','Serrano',8);

--segundo--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16351029,'Kevin','Ruiz',8);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16891001,'Celeste','Sampson',8);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16150610,'Craig','Chavez',8);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16840721,'Burke','Beach',8);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16151119,'Mannix','Porter',9);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16680622,'Leandra','Graham',8);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16120615,'Lesley','French',8);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16020927,'Irma','Blevins',8);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16030517,'Jada','Blake',8);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16380503,'Moana','Blackwell',8);

--tercero--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16450211,'Zelenia','Graham',10);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16010208,'Demetria','Perkins',10);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16041204,'Anthony','Palmer',9);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16131006,'Guy','Vasquez',9);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16870129,'Martin','Fowler',9);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16640229,'Brent','Hutchinson',9);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16040602,'Breanna','Reynolds',9);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16230704,'Autumn','Dalton',9);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16090806,'Maxwell','Goodwin',9);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16031107,'Graham','Hess',9);

--cuarto--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16550810,'Juliet','Lamb',10);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16800803,'Prescott','Moore',10);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16310916,'Catherine','Alexander',10);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16630515,'Nerea','Bright',9);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16160914,'Minerva','Hickman',10);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16030417,'Hollee','Roman',10);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16011015,'Evangeline','Banks',10);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16240409,'Kane','Roberts',10);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16260624,'Hamish','Guzman',9);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16100321,'Germaine','Powers',10);

--Quinto--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16300802,'Joel','Andrews',11);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16300908,'Hedy','Peterson',11);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16361119,'Ross','Huff',11);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16290830,'Bryar','Murray',11);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16071014,'Raja','Fernandez',12);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16120427,'Rahim','Vazquez',12);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16500907,'Raymond','Kane',11);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16361222,'Stephen','Yang',11);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16650611,'Robin','Terry',11);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16730811,'Magee','Robbins',12);

--Sexto--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16540414,'Aurelia','Beard',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16590710,'Holmes','Dorsey',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16900722,'Christen','Albert',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16470823,'Harrison','Vasquez',12);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16810625,'Sylvester','Wells',12);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16770610,'Erasmus','Berry',12);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16470526,'Murphy','Kinney',12);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16270802,'Adena','Harvey',12);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16910213,'Xavier','Curtis',12);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16110623,'Kelly','Dunlap',12);

--Septimo--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16541019,'Nigel','Salazar',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16741101,'Elton','Wagner',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16161113,'Riley','Barber',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16560207,'Griffith','Reyes',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16030220,'Brielle','Fischer',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16871210,'Helen','Solomon',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16810924,'Benjamin','Larsen',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16591210,'Bertha','Rasmussen',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16001227,'Miranda','Vasquez',14);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16981228,'Nicholas','Witt',13);

--Octavo--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16680827,'Linda','Christensen',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16311214,'Dahlia','Decker',13);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16540110,'Zephania','Harrison',14);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16080302,'Brian','Norris',14);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16520721,'Orla','Becker',14);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16611004,'Melanie','Rosa',14);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16261115,'Ingrid','Bush',14);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16210212,'Andrew','Dale',14);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16761220,'Hilary','Mcintyre',14);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16640220,'Noah','Sargent',14);

--Noveno--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16460429,'Brielle','Rich',15);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16700329,'Madaline','Pate',15);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16850209,'Jolie','Gordon',14);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16790803,'Cullen','Velez',15);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16090824,'Olivia','Lott',15);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16141023,'Oren','Hartman',15);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16741116,'Fletcher','Yang',15);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16260407,'Kimberly','Frank',15);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16031017,'Brooke','Lane',15);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16981219,'Ira','Henry',15);

--Primer Año "A" --
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16280918,'Hilda','Davidson',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16080918,'Emily','Cruz',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16410313,'Jessamine','Castillo',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16101226,'Kevyn','Harper',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16320317,'Brendan','Stafford',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16821009,'Meredith','Hayden',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16171205,'Howard','Page',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16120611,'Velma','Fletcher',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16180509,'Todd','Roberts',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16810826,'Arthur','Le',16);

--Primer Año "B"--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16070827,'Lavinia','Ortega',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16310709,'Acton','Valentine',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16680812,'Dominic','Ford',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16680122,'Hermione','Best',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16270812,'Ulla','Velez',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16100713,'Devin','Sargent',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16380721,'Reese','Welch',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16140417,'Chancellor','Stout',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16030626,'Otto','Clay',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16371227,'Chastity','Olsen',16);

--Segundo Año "A"--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16841115,'Chadwick','Salazar',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16310310,'Cora','Orr',16);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16830701,'Kuame','Salas',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16940106,'Rebecca','Blevins',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16890219,'Amery','Harmon',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16100830,'September','Hensley',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16640114,'Clarke','Wood',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16010817,'Jaden','Langley',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16020611,'Xantha','Larson',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16681025,'Ray','Huff',17);

--Segundo Año "B"--
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16770611,'Brendan','Hoover',18);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16300307,'Amela','Huff',18);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16160307,'Clayton','Zimmerman',18);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16910202,'Wendy','Salas',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16870415,'Dominique','Rollins',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16640530,'Ann','Gaines',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16660218,'Calvin','Logan',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16930211,'Sasha','Franks',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16810926,'Donovan','Weiss',17);
INSERT INTO "alumno" (nie,nombre,apellido,edad) VALUES (16590107,'Jocelyn','Melendez',17);

--
***********************************************************************************************************--
--Tabla: Seccion--
INSERT INTO "seccion" (id_nivel_grado,num_grado,letra) VALUES (1,'Kinder 4','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (2,'Kinder 5','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (3,'Preparatoria','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (4,'Primero','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (5,'Segundo','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (6,'Tercero','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (7,'Cuarto','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (8,'Quinto','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (9,'Sexto','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (10,'Septimo','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (11,'Octavo','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (12,'Noveno','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (13,'Primer Año','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (14,'Primer Año','B');
INSERT INTO "Seccion" (id,grado,letra) VALUES (15,'Segundo Año','A');
INSERT INTO "Seccion" (id,grado,letra) VALUES (16,'Segundo Año','B');

--
***********************************************************************************************************--
--Tabla: Pago--
INSERT INTO "pago" (denominacion_pago,tipo,numero) VALUES (1,'Mensualidad',60);
INSERT INTO "pago" (denominacion_pago,tipo,numero) VALUES (2,'Mensualidad',90);
INSERT INTO "pago" (denominacion_pago,tipo,numero) VALUES (3,'Mensualidad',110);

--
***********************************************************************************************************--
--Tabla: Responsable--

--Kinder 4--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16981129-3','Zelenia Mccall','Quisque@ornareelit.ca','Tia');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16350423-4','Lewis Trevino','felis.Nulla@est.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16901008-5','Gil Haney','arcu.iaculis@interdum.ca','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16161125-3','Jamal Guthrie','ligula.Donec.luctus@et.edu','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16881126-8','Ali Branch','eget.metus@dolorquam.net','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16540808-6','Ulla Rojas','vel@odiosemper.com','Madre','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16880618-3','Dominic Diaz','arcu.Morbi.sit@Suspendissealiquetmolestie.net','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16600710-7','Oscar Dorsey','scelerisque.scelerisque@Crassedleo.net','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16021027-6','Eve Clay','felis.orci.adipiscing@idsapienCras.edu','Tia');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16900809-8','Cleo Barry','tempor.bibendum.Donec@Maecenasornareegestas.ca','Tio');

--Kinder 5--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16490112-9','Lucian Flores','justo.eu.arcu@felispurus.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16431020-2','Cleo Ruiz','libero.et@commodoat.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16990614-9','Zeph Hammond','Nullam.lobortis@nisl.edu','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16470226-9','Megan Rocha','cursus.non@Integervulputate.net','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16130911-2','Giacomo Griffin','eget.lacus@est.org','Tia');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16040118-1','Clinton Cochran','magna.et.ipsum@fringillacursus.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16080725-6','Kimberley Morin','lacus@vel.edu','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16060126-0','Erich Stephenson','tristique@Vivamus.org','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16361224-2','Claire Kerr','nec.luctus@sed.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16590609-0','Paloma Wright','lorem.vitae@aodiosemper.co.uk','Madre');

--Prepa--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16200504-6','Alec Cantu','sagittis.placerat@magnis.edu','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16240112-9','Nissim Butler','mauris.id.sapien@magna.co.uk','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16650713-4','Jakeem Schultz','a.arcu.Sed@dictumeleifendnunc.co.uk','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16270208-7','Carla Thomas','cursus.Nunc.mauris@sapiencursus.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16970520-3','Dorothy Reeves','neque.vitae@iaculislacuspede.edu','Tia');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16441204-5','Rana Mckenzie','netus.et@nequepellentesque.edu','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16850627-6','Emerson Parks','ac.tellus.Suspendisse@nibhAliquam.edu','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16800813-1','Xavier York','auctor.velit@adipiscingMauris.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16500504-3','Hedy Stein','dignissim.lacus.Aliquam@tinciduntnibh.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16400724-7','Nigel Schneider','varius@lectus.co.uk','Padre');

--Primero--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16080927-4','Brock Haynes','Sed.eu@ullamcorperDuisat.net','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16130114-0','Hasad Levy','egestas.lacinia.Sed@scelerisquemollisPhasellus.edu','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16770901-5','Shaine Miller','Morbi.neque@odioAliquamvulputate.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16460827-2','Hyacinth Harvey','ante.Maecenas@Crasegetnisi.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16610405-4','Keegan Moore','vitae@nequenon.com','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16631211-0','Giselle Whitfield','eget@sempercursusInteger.co.uk','Tia');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16500905-4','Lani Dawson','malesuada.ut@auguescelerisque.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16841125-8','Britanni Brewer','nec.metus.facilisis@consequatnec.co.uk','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16891105-9','Grady Wong','eget.tincidunt@adipiscing.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16681215-0','Signe Ramirez','iaculis.nec.eleifend@enimdiam.edu','Madre');

--Segundo--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16160210-8','Jorden Roberts','ac.urna.Ut@dictumeleifendnunc.net','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16140524-5','Brooke Higgins','vel.vulputate.eu@Duiscursusdiam.net','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16191107-6','Deirdre Alford','sed.pede.nec@eget.net','Tio');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16810916-8','Palmer Berry','accumsan.neque@utquam.net','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16640525-4','Laurel Larson','Cras.eu.tellus@nisi.net','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16960806-1','Jordan Collier','a.facilisis.non@nullaIntegervulputate.com','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16241020-8','Cally Jennings','natoque@auctorodio.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16340803-6','Marshall Newton','semper.et.lacinia@enimCurabiturmassa.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16351127-0','Blossom Barlow','egestas.ligula@famesacturpis.net','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16680419-1','Jaquelyn Shelton','tincidunt.tempus@nisiAenean.co.uk','Madre');

--Tercero--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16721019-6','Reed White','nisi.sem@egetmagna.edu','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16661008-8','Calvin Waller','nulla@ligulaNullamfeugiat.net','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16740506-9','Mallory Montoya','fringilla.purus.mauris@atfringilla.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16090418-7','Noah Acevedo','massa@urna.org','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16600723-3','Samuel Kim','aliquet.lobortis.nisi@arcuSed.com','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16470414-2','Leilani Carroll','sed.pede.Cum@Sed.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16840218-3','Price Lowery','gravida.mauris@intempuseu.ca','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16291129-5','Cade Mayer','ipsum.Curabitur@anequeNullam.com','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16400615-7','Davis Watkins','erat.semper@volutpat.edu','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16960809-9','Basia Bradford','amet.lorem.semper@euismodest.edu','Madre');

--cuarto--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16271217-4','Calista Holcomb','nec.orci@purussapiengravida.co.uk','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16390408-5','Kareem Dawson','semper.dui@Phasellus.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16141016-2','Vanna Frye','pede.Nunc@eratnonummyultricies.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16491120-3','Alan Bolton','lobortis@Nullam.org','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16930229-4','Rogan Wall','vel.turpis.Aliquam@Proinvelnisl.net','Tio');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16590213-9','Olga Nielsen','amet.luctus.vulputate@infaucibusorci.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16130501-1','Maile Guzman','lobortis.risus.In@ligulatortordictum.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16320929-9','Carter Miller','odio.tristique.pharetra@Quisque.edu','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16950214-9','Nigel Shepherd','posuere.cubilia.Curae@pede.com','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16210124-5','Galvin Newman','orci.luctus.et@in.edu','Tio');

--quinto--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16511203-9','Addison Johnston','id@ipsumDonecsollicitudin.edu','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16961002-3','Sonia Mann','dapibus@arcuMorbi.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16800205-7','Wayne Mcdowell','enim@ultricesVivamusrhoncus.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16200324-3','Benjamin Sandoval','per.inceptos.hymenaeos@Nullam.ca','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16100104-6','Christen Dawson','aliquam.adipiscing.lacus@anteipsumprimis.co.uk','Tia');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16031114-9','Oren Ortiz','neque@SuspendissesagittisNullam.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16131210-1','Genevieve Curry','dolor@rhoncusNullamvelit.co.uk','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16320903-7','Sophia Lowery','accumsan@Donecfelis.edu','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16840630-4','Cain Porter','fringilla@liberoMorbiaccumsan.org','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16080114-7','Amethyst Mcpherson','eget@interdumligulaeu.net','Madre');

--sexto--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16931010-5','Kevyn Mills','magna@dolor.net','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16610725-1','Shelby Rivers','eget.tincidunt@arcuacorci.net','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16521013-0','Cameran Morin','erat@Duis.edu','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16541203-8','Kai Wagner','erat.vel.pede@Aliquamornare.co.uk','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16011212-9','Reece May','sem.Pellentesque@milacinia.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16900607-4','Rachel Donovan','Vestibulum.ut.eros@luctusvulputatenisi.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16540909-7','Catherine Bryan','ultrices@erosnon.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16881009-2','Jelani Buckner','vulputate.posuere@in.co.uk','Tia');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16510426-6','Ralph Gay','Aliquam@dictumeu.co.uk','Tio');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16800817-0','Colby Black','tellus.Aenean.egestas@liberoProin.edu','Padre');

--septimo--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16971123-0','Brandon Kerr','nec@Cum.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16630529-3','Whilemina Hinton','Suspendisse.non.leo@quamCurabiturvel.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16220723-4','Keegan Alvarez','congue@senectusetnetus.edu','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16140601-2','Ralph Castro','ligula.tortor@ipsum.com','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16681016-2','Kenyon Mcintyre','vel@Phasellus.com','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16060526-2','Jaime Witt','ligula@lectusante.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16150107-6','Tyrone Buckley','posuere.cubilia@rutrum.co.uk','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16191123-7','Leandra Huber','volutpat.Nulla.facilisis@nuncsedlibero.edu','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16970821-0','Iola Robbins','orci.luctus@Quisquepurussapien.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16860806-0','Aimee Sparks','dictum.Phasellus@vestibulum.edu','Madre');

--octavo--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16550215-9','Zorita Wood','eu@varius.co.uk','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16310806-0','Wing Lancaster','nibh@egetipsumDonec.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16440207-0','Lucian Suarez','aliquet.magna@eu.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16400414-4','Miriam Townsend','at@dolorsit.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16561113-3','Cole Schroeder','lorem.auctor.quis@Fusce.org','Tio');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16760727-2','Simon Leonard','varius.orci.in@enimCurabitur.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16240814-6','Indigo Mccoy','ullamcorper.Duis@Integermollis.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16930122-7','Theodore Middleton','tempus.lorem@necante.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16950702-9','Jenette Cameron','et.rutrum.non@auctorullamcorper.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16650613-7','Alden Durham','enim.diam.vel@elementum.net','Padre');

--noveno--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16401002-0','Eliana Maynard','malesuada.Integer.id@metusIn.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16541104-9','Daria Waters','ridiculus.mus@placeratCrasdictum.net','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16091224-5','Piper Ortega','semper@In.ca','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16610406-2','Trevor Ellison','Quisque.nonummy@semvitaealiquam.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16450528-5','Lilah Clemons','felis@lectusrutrumurna.edu','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16310612-0','Colton Davis','tincidunt.nunc.ac@DonecfringillaDonec.net','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16960704-8','Abel Alvarado','mollis.nec@arcu.net','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16880111-3','Oren Barber','Quisque@necdiamDuis.org','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16320719-7','Nevada Perry','semper@dictummagna.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16630604-3','Portia Espinoza','auctor@magnaseddui.edu','Madre');

--Primer Año A--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16260401-1','Slade Mccoy','posuere.at.velit@Morbimetus.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16590109-3','Derek Holcomb','tristique.pellentesque.tellus@metuseu.ca','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16791021-5','Calista Gentry','senectus@bibendumfermentummetus.co.uk','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16050714-2','Ginger Cortez','dolor.egestas.rhoncus@ametrisusDonec.net','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16430917-3','Irma Barnes','lobortis@Fuscealiquet.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16740216-2','Cherokee Luna','pellentesque@Nullamvitaediam.edu','Tia');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16280915-4','Martin Clark','vulputate.posuere@mollisIntegertincidunt.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16110217-8','Erich Garrison','lacus.Quisque@dictumPhasellus.org','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16070620-1','Melanie Hodges','ante@ipsum.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16541109-4','Gannon Ferguson','ac.arcu@malesuada.co.uk','Madre');

--Primer Año B--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16841009-9','Honorato Cash','neque.sed.dictum@Morbiquisurna.com','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16850501-3','Britanni Wade','nibh@egettincidunt.net','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16211105-7','Brock Holmes','venenatis@ac.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16120703-8','Fallon Heath','ligula.Nullam.enim@Integertincidunt.co.uk','Tio');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16790114-5','Walker Chandler','ut.nulla@duiCum.edu','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16780313-7','Harding Vaughn','non.luctus@dui.ca','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16040422-5','Alvin Joseph','accumsan.interdum.libero@Suspendisseeleifend.net','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16860806-1','Zenia Holder','orci.adipiscing@lorem.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16670914-6','Plato Carrillo','Donec.tempor.est@tacitisociosquad.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16910711-3','Davis Espinoza','felis@orciPhasellusdapibus.co.uk','Padre');

--Segundo Año A--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16940314-3','Quentin Valentine','sit.amet.consectetuer@elitfermentum.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16390511-9','Lamar Puckett','enim.nec@duinectempus.ca','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16411113-1','Charissa Delacruz','Fusce.aliquam@metusurna.co.uk','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16750519-2','Colleen Mccall','Phasellus.vitae.mauris@lectusrutrum.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16820427-2','McKenzie Flowers','tempus.lorem@liberoMorbi.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16841125-3','Evelyn Cotton','ipsum.ac@sitamet.edu','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16610408-0','Ulla Walker','et.risus@necurnaet.net','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16870724-7','Fitzgerald Miller','lectus.a@montesnascetur.com','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16280719-1','Xantha Collins','conubia.nostra.per@nunc.com','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16350504-0','McKenzie Thornton','ante@duiCraspellentesque.edu','Madre');

--Segundo Año B--
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16490912-5','September Mcdonald','tincidunt.nibh.Phasellus@arcuiaculis.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16770807-1','Ezekiel Edwards','lorem.vitae@nuncullamcorpereu.org','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16530524-1','Camden Mullins','sem@scelerisque.edu','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16161122-0','Maisie Ballard','pulvinar@condimentum.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16110703-4','Jacob Mosley','nascetur.ridiculus.mus@metus.com','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16810809-9','Ima Hopper','placerat.augue@famesac.org','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16320124-9','Eric Larsen','eu.ligula.Aenean@maurisanunc.co.uk','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16760603-2','Uma Harmon','pede.Praesent.eu@elementumsem.ca','Madre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16110604-8','Felix Vance','tempus.lorem.fringilla@Vivamus.com','Padre');
INSERT INTO "responsable" (id,nombre,email,parentesco) VALUES ('16180504-3','Mara Pugh','nisl@eunequepellentesque.net','Madre');

--
***********************************************************************************************************--
--Tabla: Docente--

INSERT INTO "Docente" (dui,nombre,email) VALUES ('16970415-5','Kyla Wallace','elit@luctus.net');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16351211-8','Wynne Knight','et@montesnasceturridiculus.org');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16851203-6','Xandra Hudson','nisi.Cum.sociis@tempor.ca');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16380520-5','Patricia Greer','magnis.dis.parturient@vehiculaPellentesque.com');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16770629-9','Indira Whitney','urna.Vivamus@risusInmi.ca');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16830727-5','Signe Holder','Suspendisse.sed@Etiam.co.uk');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16991127-9','Laura Craft','In.scelerisque.scelerisque@Quisque.org');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16990125-2','Stella Mcintyre','sed.sem@iaculisodio.com');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16480905-3','Driscoll Wheeler','mi.pede@ullamcorper.com');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16461023-8','Reuben Parrish','Nulla.eget@Duisdignissim.edu');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16990410-4','Ryan Mcleod','risus.Morbi.metus@lectuspedeet.com');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16280226-9','Jade Miller','aliquet@dui.ca');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16291004-4','Armando Day','cubilia@elitpede.org');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16761006-4','Callum Kirk','ipsum@mattissemper.com');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16441015-4','Leslie Kelley','Aliquam.erat.volutpat@pedeetrisus.net');
INSERT INTO "Docente" (dui,nombre,email) VALUES ('16701229-2','Cullen Everett','bibendum@enimSuspendisse.net');

--***********************************************************************************************************--
--Tabla: Subvencion--
INSERT INTO "Subvencion" (id,tipo,numero) VALUES (1,'Descuento',20);
INSERT INTO "Subvencion" (id,tipo,numero) VALUES (2,'Descuento',30);
INSERT INTO "Subvencion" (id,tipo,numero) VALUES (3,'Descuento',40);
INSERT INTO "Subvencion" (id,tipo,numero) VALUES (4,'Descuento',50);

--***********************************************************************************************************--
--Tabla: Carrera--
INSERT INTO "carrera" (id_carrera,nombre) VALUES (1,'Licenciatura en Matematicas');
INSERT INTO "carrera" (id_carrera,nombre) VALUES (2,'Licenciatura en Lenguaje');
INSERT INTO "carrera" (id_carrera,nombre) VALUES (3,'Licenciatura en Ciencias');
INSERT INTO "carrera" (id_carrera,nombre) VALUES (4,'Licenciatura en Sociales');
INSERT INTO "carrera" (id_carrera,nombre) VALUES (5,'Licenciatura en Educacion Fisica');
INSERT INTO "carrera" (id_carrera,nombre) VALUES (6,'Licenciatura en Docencia Kinder');

--***********************************************************************************************************--
--Tabla: Edificio--
INSERT INTO "edificio" (denominacion_edificio,nombre) VALUES (1,'Kinder');
INSERT INTO "edificio" (denominacion_edificio,nombre) VALUES (2,'Basica');
INSERT INTO "edificio" (denominacion_edificio,nombre) VALUES (3,'Media');

--***********************************************************************************************************--
--Tabla: Anno--
INSERT INTO "anio" (id_num_anio) VALUES (1);
INSERT INTO "anio" (id_num_anio) VALUES (2);

--***********************************************************************************************************--
--Tabla: Empleado--
INSERT INTO "empleado" (id_responsable_empleado,nombre,email,oficio) VALUES ('16370113-1','Emerson Gallagher','Nunc.quis.arcu@dolortempus.edu','Conserge');
INSERT INTO "empleado" (id_responsable_empleado,nombre,email,oficio) VALUES ('16391105-4','Fredericka Sampson','malesuada.augue.ut@semperdui.org','Secretaria');
INSERT INTO "empleado" (id_responsable_empleado,nombre,email,oficio) VALUES ('16950912-1','Laura Battle','nunc.sed.pede@tristiquepharetra.com','Bibliotecaria');
INSERT INTO "empleado" (id_responsable_empleado,nombre,email,oficio) VALUES ('16300730-4','Barry Skinner','rutrum@eunibhvulputate.edu','Vigilante');
INSERT INTO "empleado" (id_responsable_empleado,nombre,email,oficio) VALUES ('16531204-4','Sheila Paul','pede.Suspendisse@vehicularisus.edu','Secretaria');
INSERT INTO "empleado" (id_responsable_empleado,nombre,email,oficio) VALUES ('16790407-8','Tashya Tran','metus@etmalesuada.edu','Vigilante');


--***********************************************************************************************************--
--Tabla: Estudiante--
--Kinder 4--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16981120,'Chancellor','16981129-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16420327,'Ulric','16350423-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16500116,'Tanek','16901008-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16801118,'Samantha','16161125-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16490216,'Camilla','16881126-8');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16360718,'Sawyer','16540808-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16130113,'Marvin','16880618-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16340112,'Ramona','16600710-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16971101,'Charles','16021027-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16360622,'Faith','16900809-8');

--kinder 5--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16010603,'Jakeem','16490112-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16840725,'Madison','16431020-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16340111,'Anne','16990614-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16250714,'Melissa','16470226-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16990801,'Reed','16130911-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16820907,'Kennedy','16040118-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16650523,'Chantale','16080725-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16420515,'Cade','16060126-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16440801,'Riley','16361224-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16081015,'Isabella','16590609-0');

--Prepa --
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16381121,'Nina','16200504-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16220615,'David','16240112-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16570110,'Carter','16650713-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16980202,'Calvin','16270208-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16800622,'Jessamine','16970520-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16620716,'Xanthus','16441204-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16920319,'Florence','16850627-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16260113,'Leila','16800813-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16371118,'Ursula','16500504-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16311217,'Ferdinand','16400724-7');

--primero--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16540104,'Baker','16080927-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16560817,'Cecilia','16130114-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16611027,'Kirby','16770901-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16820129,'Jarrod','16460827-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16380305,'Dalton','16610405-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16171119,'Reuben','16631211-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16340712,'Leo','16500905-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16310212,'Moana','16841125-8');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16471222,'Paul','16891105-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16421010,'Nero','16681215-0');

--segundo--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16351029,'Kevin','16160210-8');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16891001,'Celeste','16140524-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16150610,'Craig','16191107-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16840721,'Burke','16810916-8');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16151119,'Mannix','16640525-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16680622,'Leandra','16960806-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16120615,'Lesley','16241020-8');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16020927,'Irma','16340803-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16030517,'Jada','16351127-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16380503,'Moana','16680419-1');

--tercero--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16450211,'Zelenia','16721019-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16010208,'Demetria','16661008-8');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16041204,'Anthony','16740506-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16131006,'Guy','16090418-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16870129,'Martin','16600723-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16640229,'Brent','16470414-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16040602,'Breanna','16840218-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16230704,'Autumn','16291129-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16090806,'Maxwell','16400615-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16031107,'Graham','16960809-9');

--cuarto--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16550810,'Juliet','16271217-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16800803,'Prescott','16390408-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16310916,'Catherine','16141016-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16630515,'Nerea','16491120-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16160914,'Minerva','16930229-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16030417,'Hollee','16590213-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16011015,'Evangeline','16130501-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16240409,'Kane','16320929-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16260624,'Hamish','16950214-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16100321,'Germaine','16210124-5');

--Quinto--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16300802,'Joel','16511203-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16300908,'Hedy','16961002-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16361119,'Ross','16800205-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16290830,'Bryar','16200324-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16071014,'Raja','16100104-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16120427,'Rahim','16031114-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16500907,'Raymond','16131210-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16361222,'Stephen','16320903-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16650611,'Robin','16840630-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16730811,'Magee','16080114-7');

--Sexto--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16540414,'Aurelia','16931010-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16590710,'Holmes','16610725-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16900722,'Christen','16521013-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16470823,'Harrison','16541203-8');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16810625,'Sylvester','16011212-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16770610,'Erasmus','16900607-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16470526,'Murphy','16540909-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16270802,'Adena','16881009-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16910213,'Xavier','16510426-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16110623,'Kelly','16800817-0');

--Septimo--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16541019,'Nigel','16971123-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16741101,'Elton','16630529-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16161113,'Riley','16220723-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16560207,'Griffith','16140601-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16030220,'Brielle','16681016-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16871210,'Helen','16060526-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16810924,'Benjamin','16150107-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16591210,'Bertha','16191123-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16001227,'Miranda','16970821-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16981228,'Nicholas','16860806-0');

--Octavo--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16680827,'Linda','16550215-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16311214,'Dahlia','16310806-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16540110,'Zephania','16440207-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16080302,'Brian','16400414-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16520721,'Orla','16561113-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16611004,'Melanie','16760727-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16261115,'Ingrid','16240814-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16210212,'Andrew','16930122-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16761220,'Hilary','16950702-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16640220,'Noah','16650613-7');

--Noveno--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16460429,'Brielle','16401002-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16700329,'Madaline','16541104-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16850209,'Jolie','16091224-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16790803,'Cullen','16610406-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16090824,'Olivia','16450528-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16141023,'Oren','16310612-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16741116,'Fletcher','16960704-8');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16260407,'Kimberly','16880111-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16031017,'Brooke','16320719-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16981219,'Ira','16630604-3');

--Primer Año "A" --
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16280918,'Hilda','16260401-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16080918,'Emily','16590109-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16410313,'Jessamine','16791021-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16101226,'Kevyn','16050714-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16320317,'Brendan','16430917-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16821009,'Meredith','16740216-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16171205,'Howard','16280915-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16120611,'Velma','16110217-8');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16180509,'Todd','16070620-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16810826,'Arthur','16541109-4');

--Primer Año "B"--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16070827,'Lavinia','16841009-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16310709,'Acton','16850501-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16680812,'Dominic','16211105-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16680122,'Hermione','16120703-8');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16270812,'Ulla','16790114-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16100713,'Devin','16780313-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16380721,'Reese','16040422-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16140417,'Chancellor','16860806-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16030626,'Otto','16670914-6');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16371227,'Chastity','16910711-3');

--Segundo Año "A"--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16841115,'Chadwick','16940314-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16310310,'Cora','16390511-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16830701,'Kuame','16411113-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16940106,'Rebecca','16750519-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16890219,'Amery','16820427-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16100830,'September','16841125-3');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16640114,'Clarke','16610408-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16010817,'Jaden','16870724-7');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16020611,'Xantha','16280719-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16681025,'Ray','16350504-0');

--Segundo Año "B"--
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16770611,'Brendan','16490912-5');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16300307,'Amela','16770807-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16160307,'Clayton','16530524-1');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16910202,'Wendy','16161122-0');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16870415,'Dominique','16110703-4');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16640530,'Ann','16810809-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16660218,'Calvin','16320124-9');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16930211,'Sasha','16760603-2');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16810926,'Donovan','16110604-8');
INSERT INTO "estudiante" (id_estudiante_responsable,nombre,dui_docente) VALUES (16590107,'Jocelyn','16180504-3');


--***********************************************************************************************************--
--Tabla: Profesor--

INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (1,'16970415-5','Kyla Wallace');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (2,'16351211-8','Wynne Knight');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (3,'16851203-6','Xandra Hudson');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (4,'16380520-5','Patricia Greer');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (5,'16770629-9','Indira Whitney');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (6,'16830727-5','Signe Holder');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (7,'16991127-9','Laura Craft');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (8,'16990125-2','Stella Mcintyre');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (9,'16480905-3','Driscoll Wheeler');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (10,'16461023-8','Reuben Parrish');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (11,'16990410-4','Ryan Mcleod');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (12,'16280226-9','Jade Miller');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (13,'16291004-4','Armando Day');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (14,'16761006-4','Callum Kirk');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (15,'16441015-4','Leslie Kelley');
INSERT INTO "profesor" (id_profesor_docente,dui_docente,nombre) VALUES (16,'16701229-2','Cullen Everett');

INSERT INTO "otorga" (id_alumno,id_susbvencion,num_anio) VALUES (1,1,2016);

select * from alumno;

select * from profesor;

--1. mostrar los alumnos de parvularia

select * from alumno where edad between 4 and 6;

--2. mostrar los alumnos de bachillerato

select * from aluumno where edad between 16 and 17;


--3. mostrar los alumnos de segundo año b y ordenarlos en orden alfabetico

select a.nie,a.nombre, a.apellido, s.grado, s.letra
from alumno a, seccion s
where a.id_seccion = s.id_seccion
AND edad = 17
order by nombre asc;	

--4. mostrar los profesores y al edificio a que pertenece

select pr.dui_docente pr.nombre, e.edificio
from profesor pr, edifcio e;

--5. Liste los alumnos (todos sus atributos) y muestre los alumnos con
-- mensualidad de 110

SELECT a.nie, a.nombre, p.descripcion, t.numero
FROM alumno a, pago p
WHERE p.numero = 110
ORDER BY a.nombre asc;




